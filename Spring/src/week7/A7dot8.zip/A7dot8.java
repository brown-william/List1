/**
 * 
 */
package week7;

/**
 * @author Nate
 *
 */
public class A7dot8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		double[] firstArray = {4,22.2,13,9,6,24.1,18,7.5};
		
	
		
		
		
		System.out.println(average(firstArray));
		
		
		
	}
	public static int average(int[] firstArray)   {
		
		for(int i = 0; i < firstArray.length; i++) {
			
			int sum = 0 + firstArray[i];
			
			int theAverage = sum / firstArray.length;
			
			
		}
		return theAverage;
			
			
		
		
		
	}
	
	public static double average(double[] firstArray)  {
		double sum = 0;
		
		for(int i = 0; i < firstArray.length; i++) {
			
			double addSum = sum + firstArray[i];
			
			double theAverage = sum / firstArray.length;
			
			
		}
		return theAverage;
	
		
		
		
		
	}
	
}
