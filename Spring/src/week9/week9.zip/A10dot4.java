package week9;

public class A10dot4 {
		
	
	public static void main(String[] args) {
			
		
		
		MyPoint newPointA = new MyPoint(0,0);
		MyPoint newPointB = new MyPoint(10,30.5);
		
		System.out.println(newPointA.distance(newPointB));
		
		}
}
